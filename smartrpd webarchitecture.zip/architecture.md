# SmartRPD Web Architecture and Data Flow

## Scope

This document describes the current SmartRPD web delivery path, the Google Cloud runtime, the main user data flows, and the security controls relevant to review and URL/file-transfer approval. SmartRPD uses a static frontend on GitHub Pages and a separate API and data tier on Google Cloud Platform.

The approved operating process permits anonymised dental scans and anonymised case identifiers only. Patient names, NRIC numbers, dates of birth, medical record numbers, contact details and clinical notes are outside the approved data scope.

## Components

| Component | Purpose | Confirmed detail |
|---|---|---|
| Authorised user | Uses SmartRPD through a managed browser | Individual username and password; standard and administrator roles |
| GitHub repository | Stores version-controlled frontend source and deployment workflow | Source history and branch controls |
| GitHub Actions | Verifies and publishes the static frontend | Manual trigger, Node 22, deterministic install, lint, tests, production build, SHA-256 manifest |
| GitHub Pages frontend | Delivers the SmartRPD browser interface | Static HTML, CSS, JavaScript, 2D annotation and Three.js 3D viewer; no backend or database |
| GCP HTTPS boundary | Public entry point for API traffic | External HTTPS Load Balancer, TLS certificate and Cloud Armor policy |
| SmartRPD API server | Authenticates users and serves case/file operations | Compute Engine VM at private address `10.148.0.2`; API base `https://live.api.smartrpdai.com/api/smartrpd` |
| Database server | Stores application records and file metadata | Compute Engine VM at private address `10.148.0.3`; TCP 3306 internal only |
| Cloud Storage | Stores approved anonymised files | `gs://rpdcloudstorage`, Singapore region |
| Operations and evidence | Holds security evidence and operational ownership | Authentication-failure logging and 14-day backup retention were previously documented; monitoring alerts, patch cadence and formal SAST/DAST gates require confirmation |

## GitHub and Google Cloud Interaction

GitHub and Google Cloud have separate responsibilities:

1. GitHub stores, tests, builds and publishes the static frontend.
2. GitHub Pages sends the frontend files to the user's browser.
3. The browser, not GitHub Pages, calls the SmartRPD API over HTTPS.
4. The GCP load balancer terminates TLS and applies Cloud Armor filtering.
5. The API performs authentication, role checks, case operations and file handling.
6. The API communicates privately with the database and Cloud Storage.

GitHub Pages does not connect directly to the database, and the database is not exposed to the browser.

## Main Flows

### Open the web application

The user loads `https://ndcs-smartrpd.github.io/tmp.rpd/`. GitHub Pages returns static frontend assets. No patient or case data is processed by GitHub Pages as an application backend.

### Login and access

The frontend posts the user's assigned username and password to the GCP API. The request enters through the HTTPS load balancer and Cloud Armor policy. The API checks account information in the internal database and returns the authorised role. Administrative operations are checked by the backend, not only by the browser interface.

### Upload anonymised scan

The user selects an approved anonymised STL or image file. The frontend sends Base64 file data inside an HTTPS JSON request to the SmartRPD API. The API stores the object in Cloud Storage and associated metadata in the internal database.

### View and download

The frontend requests authorised case files from the API. The API checks case access, retrieves data from the internal database and Cloud Storage, and returns it through HTTPS. Three.js renders the model locally in the browser. Approved downloads may include STL, JPG/JPEG, PNG, ZIP and generated DOCX files.

### Deploy the frontend

An authorised repository operator manually starts the deployment workflow. GitHub Actions installs dependencies from the lockfile, runs lint and tests, builds the production bundle, produces a revision/digest manifest and publishes the verified content to the configured Pages branch. Git history supports rollback to an earlier deployment.

## Security Controls

### Confirmed technical controls

- HTTPS for the frontend and API.
- TLS termination and certificate at the GCP external Application Load Balancer.
- Cloud Armor policy attached to the API load balancer.
- Private API and database addresses within GCP.
- Database TCP 3306 restricted to internal communication; no browser-to-database path.
- Individual application accounts, backend role checks and administrator-only endpoints.
- Machine identifier and user UUID included in authenticated API request context.
- Deterministic CI install, lint, automated tests, production build and release SHA-256 manifest.
- Git version history supporting deployment traceability and rollback.
- Authentication-failure logging recorded in previous security documentation.
- Backup retention covering the previous 14 days recorded in previous security evidence.
- Anonymisation before upload and anonymised case identifiers as an operational requirement.

### URL and API filtering

Use narrow allowlisting where the enterprise filtering platform supports path-based rules:

- Frontend: `https://ndcs-smartrpd.github.io/tmp.rpd/*`
- API: `https://live.api.smartrpdai.com/api/smartrpd/*`
- Required API methods: `GET`, `POST` and browser preflight `OPTIONS`, where used.

Allowing only the frontend is insufficient because login, case operations and file transfer are performed against the API hostname. Avoid broad rules such as `*.github.io` when the exact SmartRPD path can be approved.

### Evidence still required before claiming implementation

- GCP monitoring dashboards, alert thresholds, notification recipients and log-retention periods.
- Operating-system and application patch owner, patch frequency, emergency patch procedure and evidence of completed patching.
- Formal vulnerability-management cadence, responsible owner and remediation service levels.
- Whether SAST and DAST are mandatory deployment gates; current repository evidence confirms lint, tests, build and dependency-audit reporting, but not formal SAST/DAST blocking gates.
- Cloud Armor rule export and periodic rule-review evidence.
- Backup restore-test evidence and responsible owner.

## Important Source-of-Truth Note

The current deployment workflow defines the frontend URL as `https://ndcs-smartrpd.github.io/tmp.rpd/`. Some older setup documentation still mentions `https://faid123.github.io/.tmp-test-web/`. The EMSCR and allowlisting request should use the current deployed URL after the project owner verifies it in GitHub Pages settings.
